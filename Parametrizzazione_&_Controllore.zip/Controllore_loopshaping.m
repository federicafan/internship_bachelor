clear variables
close all
clc

format long

s=tf('s');
Ts=1e-3;
G_p=load('transfer_function');
G1=G_p.G;
ZOH=1/(1+s*Ts*0.5);
G_ZOH=G1*ZOH;

%Steady-state
Kc=50;
Css=-Kc/s;
Lss=Css*G_ZOH;
figure(); bode(Lss), grid on;

%Transient
Tp=3.35;
Sp=4.91;
wc_des=13;
figure(); nichols(Lss,'k'); hold on; t_grid(Tp); s_grid(Sp);
%Lead network, real negative zero
wx=79.7;
wn=3; %wn=2.1
wz=wx/wn;
Cz=(1+s/wz)^2;
C0=Css*Cz;
L1=C0*G_ZOH;
hold on; nichols(L1,'b');
%Closure pole
wp=2000;
Cp=1/(1+s/wp);
C0=C0*Cp;
L2=L1*Cp;
hold on; nichols(L2,'r');

%Discretizzazione
Cd=c2d(C0,Ts,'tustin')

%Simulazione
%%Tracking error, step + transient + u(t)
r_s=1;
rho=1;
rho_ramp=0;
t_stop=0.4;
min_step=1e-5;
max_step=1e-3;
sim('Levitatore_lin');
figure();
title('Step response');
plot(r.time,r.data,'r','Linewidth',1.5);
hold on;
plot(y.time,y.data,'b','Linewidth',1.5);
figure();
plot(u.time,u.data,'r','Linewidth',1.5);
figure();
plot(e.time,e.data,'r','Linewidth',1.5);
%%Ramp Response
r_s=-1;
rho=0;
rho_ramp=1;
sim('Levitatore_lin');
figure();
plot(r.time,r.data,'r','Linewidth',1.5);
hold on;
plot(y.time,y.data,'b','Linewidth',1.5);
figure();
plot(e.time,e.data,'r','Linewidth',1.5);

